#ifndef _CUED_DELAY_INCLUDED
#define _CUED_DELAY_INCLUDED

#ifndef __cplusplus
#error delay.h must be used from C++, not C code
#endif

void delay(int);

#endif  /* _CUED_DELAY_INCLUDED */
